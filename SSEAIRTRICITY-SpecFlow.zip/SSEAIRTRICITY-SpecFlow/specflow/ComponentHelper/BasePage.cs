﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Threading;
using NUnit.Framework;

namespace specflow
{
    abstract class BasePage
    {

        protected IWebDriver driver;
        protected WebDriverWait wait;

        public BasePage(IWebDriver driver)
        {
            this.driver = driver;
            this.wait = new WebDriverWait(driver,new TimeSpan( 20000));
        }

        public void enterText(IWebElement element, String text)
        {
            element.Clear();
            element.SendKeys(text);
        }

        public void waitAndClick(IWebElement element)
        {
            wait.Until(ExpectedConditions.ElementToBeClickable(element));
            element.Click();
        }
        public object ExecuteScript(string script, params object[] args)
        {
            IJavaScriptExecutor executor = ((IJavaScriptExecutor) driver);
            return executor.ExecuteScript(script, args);
        }
        public void ScrollToAndClick(IWebElement element)
        {
            ExecuteScript("window.scrollTo(0," + element.Location.Y + ")");
            Thread.Sleep(3000);
            element.Click();
        }

        public void clickBasedOnText(IList<IWebElement> element, String textValue)
        {
            Console.WriteLine("Nilesh");
            foreach (IWebElement actualGetTextValue in element)
            {
                
                if (actualGetTextValue.Text.Equals(textValue))
                {
                    actualGetTextValue.Click();
                    break;
                }
            }
        }

        public void selectDropDownValue(IList<IWebElement> element, String textValue)
        {
            foreach (IWebElement actualGetTextValue in element)
            {
                if (actualGetTextValue.Text.Equals(textValue))
                {
                    actualGetTextValue.Click();
                    break;
                }
            }
        }
        public bool IsElementVisible(IWebElement element)
        {
            try
            {
                return element.Displayed && element.Enabled;
            }
            catch (NoSuchElementException ex)
            {
                return false;
            }
        }

        public bool IsElemetPresent(IList<IWebElement> element)
        {
            try
            {
                return element.Count == 1;
            }
            catch (Exception)
            {
                return false;
            }
        }
        private bool IsElemetPresent(By by)
        {
            throw new NotImplementedException();
        }

        public void getAllTableValues()
        {
            List<string> list = new List<string>();

            int table_row_count = getRowCount();
            int table_column_count = getColumnCount();

            for(int i=0;i<table_row_count;i++)
            {
                for(int j = 0; j < table_column_count; j++)
                {
                    string table_xpath = $"//table[@role='table']/tbody/tr[{i}]/td[{j}]";
                    list.Add(driver.FindElement(By.XPath("table_xpath")).Text);
                }
            }
        }

        public int getRowCount()
        {

            IList<IWebElement> element = driver.FindElements(By.XPath("//table[@role='table']/tbody/tr"));
            int rowCount= element.Count;
            return rowCount;
        }

        public int getColumnCount()
        {
            IList<IWebElement> element = driver.FindElements(By.XPath("//table[@role='table']/tbody/tr/td"));
            int columnCount = element.Count;
            return columnCount;
        }

        public IList<string> getTextsTableResult(IList<IWebElement> element)
        {
            List<string> list = new List<string>();
            string textValue="";

            if (element.Count > 0)
            {
                foreach (IWebElement tableValues in element)
                {
                    textValue = tableValues.Text;
                    list.Add(textValue);
                    Console.WriteLine("Display Appliancies Table Values => ", textValue);
                }
            }

            return list;
        }

        public void AreEqual(string expected, IWebElement element)
        {
            String actualString = element.Text;
            Assert.IsTrue(actualString.Contains(expected));
        }
    }
}
