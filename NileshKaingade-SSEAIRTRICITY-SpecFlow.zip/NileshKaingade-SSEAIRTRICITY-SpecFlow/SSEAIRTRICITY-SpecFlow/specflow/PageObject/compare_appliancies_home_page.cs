﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Configuration;
using Framework.Settings;

namespace specflow
{
    class CompareApplianciesHomePage : BasePage
    {
        [FindsBy(How = How.XPath, Using = "//a[@class='btn-secondary btn-small js-toggle-extent-dialog']")]
        public IWebElement adviceResidentFrom { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-small']")]
        public IList<IWebElement> selectResidentFrom { get; set; }

        [FindsBy(How = How.XPath, Using = "//select[@name='appliance']/option")]
        public IList<IWebElement> addAppliance { get; set; }

        [FindsBy(How = How.Id, Using = "hours")]
        public IWebElement average_hours { get; set; }

        [FindsBy(How = How.Id, Using = "mins")]
        public IWebElement average_mins { get; set; }

        [FindsBy(How = How.Id, Using = "kwhcost")]
        public IWebElement electrical_average_rate { get; set; }

        [FindsBy(How = How.Id, Using = "submit")]
        public IWebElement add_appliance_to_your_list { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@role='table']/tbody/tr/td")]
        public IList<IWebElement> applianceTableDetails { get; set; }

        [FindsBy(How = How.XPath, Using = "//p[contains(.,'The advice on this website doesn’t cover Northern Ireland')]")]
        public IWebElement errorMessage { get; set; }

        [FindsBy(How = How.ClassName, Using = "cads-logo")]
        public IWebElement advice_Logo { get; set; }
        
        public CompareApplianciesHomePage(IWebDriver driver) : base(driver)
        {
            PageFactory.InitElements(driver, this);
        }

        string WebSite = ConfigurationManager.AppSettings.Get(AppConfigKeys.WebSite);
        public void goTo()
        {
            driver.Navigate().GoToUrl(WebSite);
        }

        public void selectAdviceResidentFrom()
        {
            waitAndClick(adviceResidentFrom);
        }

        public void selectResidentFromValue(string selectBasedOnValue)
        {
            clickBasedOnText(selectResidentFrom, selectBasedOnValue);
        }
        public void addListOfAppliance(string dropDownValue)
        {
            selectDropDownValue(addAppliance, dropDownValue);
        }

        public void enterAverageHours(string addAverageAppliance)
        {
            enterText(average_hours, addAverageAppliance);
            enterText(average_mins, addAverageAppliance);
        }

        public void enterElectricalAverageRate(string average_rate)
        {
            if (IsElementVisible(electrical_average_rate))
            {
                enterText(electrical_average_rate, average_rate);
            }
        }

        public void selectAddApplianceToYourListButton()
        {
            ScrollToAndClick(add_appliance_to_your_list);
            Thread.Sleep(300);
        }

        public void displayApplianceResult()
        {
            getTextsTableResult(applianceTableDetails);
        }

        public void verifyErrorMessageOnScreen(String expected_error_message)
        {
            Console.WriteLine("In Page = ");
            AreEqual(expected_error_message, errorMessage);
        }

        public void verifyCitizenAdvicePage()
        {
            IsElementVisible(advice_Logo);
        }
    }
}
